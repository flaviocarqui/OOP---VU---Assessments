﻿using ConferenceManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ConferenceManagementSystem.DataAccess
{
    public class ConferenceManagementContext : DbContext
    {
        public ConferenceManagementContext() : base() { }

        public DbSet<Conference> Conferences { get; set; }
        public DbSet<Organizer> Organizers { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Attendee> Attendees { get; set; }
        public DbSet<Registration> Registrations { get; set; }
    }
}