namespace ConferenceManagementSystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Attendees",
                c => new
                    {
                        AttendeeID = c.Int(nullable: false, identity: true),
                        FirstName = c.String(),
                        LastName = c.String(),
                        Email = c.String(),
                        Phone = c.String(),
                    })
                .PrimaryKey(t => t.AttendeeID);
            
            CreateTable(
                "dbo.Registrations",
                c => new
                    {
                        RegistrationID = c.Int(nullable: false, identity: true),
                        RegistrationDate = c.DateTime(nullable: false),
                        Attendee_AttendeeID = c.Int(),
                        Event_EventID = c.Int(),
                    })
                .PrimaryKey(t => t.RegistrationID)
                .ForeignKey("dbo.Attendees", t => t.Attendee_AttendeeID)
                .ForeignKey("dbo.Events", t => t.Event_EventID)
                .Index(t => t.Attendee_AttendeeID)
                .Index(t => t.Event_EventID);
            
            CreateTable(
                "dbo.Events",
                c => new
                    {
                        EventID = c.Int(nullable: false, identity: true),
                        EventName = c.String(),
                        Topic = c.String(),
                        Date = c.DateTime(nullable: false),
                        Conference_ConferenceID = c.Int(),
                    })
                .PrimaryKey(t => t.EventID)
                .ForeignKey("dbo.Conferences", t => t.Conference_ConferenceID)
                .Index(t => t.Conference_ConferenceID);
            
            CreateTable(
                "dbo.Conferences",
                c => new
                    {
                        ConferenceID = c.Int(nullable: false, identity: true),
                        Location = c.String(),
                        Year = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ConferenceID);
            
            CreateTable(
                "dbo.Organizers",
                c => new
                    {
                        OrganizerID = c.Int(nullable: false, identity: true),
                        FirstName = c.String(),
                        LastName = c.String(),
                        Phone = c.String(),
                    })
                .PrimaryKey(t => t.OrganizerID);
            
            CreateTable(
                "dbo.OrganizerConferences",
                c => new
                    {
                        Organizer_OrganizerID = c.Int(nullable: false),
                        Conference_ConferenceID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Organizer_OrganizerID, t.Conference_ConferenceID })
                .ForeignKey("dbo.Organizers", t => t.Organizer_OrganizerID, cascadeDelete: true)
                .ForeignKey("dbo.Conferences", t => t.Conference_ConferenceID, cascadeDelete: true)
                .Index(t => t.Organizer_OrganizerID)
                .Index(t => t.Conference_ConferenceID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Registrations", "Event_EventID", "dbo.Events");
            DropForeignKey("dbo.OrganizerConferences", "Conference_ConferenceID", "dbo.Conferences");
            DropForeignKey("dbo.OrganizerConferences", "Organizer_OrganizerID", "dbo.Organizers");
            DropForeignKey("dbo.Events", "Conference_ConferenceID", "dbo.Conferences");
            DropForeignKey("dbo.Registrations", "Attendee_AttendeeID", "dbo.Attendees");
            DropIndex("dbo.OrganizerConferences", new[] { "Conference_ConferenceID" });
            DropIndex("dbo.OrganizerConferences", new[] { "Organizer_OrganizerID" });
            DropIndex("dbo.Events", new[] { "Conference_ConferenceID" });
            DropIndex("dbo.Registrations", new[] { "Event_EventID" });
            DropIndex("dbo.Registrations", new[] { "Attendee_AttendeeID" });
            DropTable("dbo.OrganizerConferences");
            DropTable("dbo.Organizers");
            DropTable("dbo.Conferences");
            DropTable("dbo.Events");
            DropTable("dbo.Registrations");
            DropTable("dbo.Attendees");
        }
    }
}
