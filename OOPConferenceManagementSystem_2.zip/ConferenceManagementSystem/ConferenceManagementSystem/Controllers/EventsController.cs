﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ConferenceManagementSystem.DataAccess;
using ConferenceManagementSystem.Models;

namespace ConferenceManagementSystem.Controllers
{
    public class EventsController : Controller
    {
        private ConferenceManagementContext db = new ConferenceManagementContext();

        // GET: Events
        public ActionResult Index()
        {
            return View(db.Events.ToList());
        }

        // GET: Events/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        // GET: Events/Create
        public ActionResult Create()
        {
            ViewBag.Conferences = new SelectList(db.Conferences.ToList(), "ConferenceID", "Location");
            return View();
        }

        // POST: Events/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EventID,EventName,Topic,Date")] Event @event, FormCollection form)
        {
            if (ModelState.IsValid)
            {
                int conferenceID = Convert.ToInt32(form["Conference.ConferenceID"]);
                @event.Conference = db.Conferences.Find(conferenceID);
                db.Events.Add(@event);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Conferences = new SelectList(db.Conferences.ToList(), "ConferenceID", "Location");
            return View(@event);
        }

        // GET: Events/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            ViewBag.Conferences = new SelectList(db.Conferences.ToList(), "ConferenceID", "Location", @event.Conference.ConferenceID);
            return View(@event);
        }

        // POST: Events/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int EventID, FormCollection form)
        {
            Event @event = db.Events.Include(i => i.Conference).Where(i => i.EventID == EventID).Single();
            if (ModelState.IsValid)
            {
                @event.EventName = form["EventName"].ToString();
                @event.Topic = form["Topic"].ToString();
                @event.Date = Convert.ToDateTime(form["Date"]);
                int conferenceID = Convert.ToInt32(form["Conference.ConferenceID"]);
                @event.Conference = db.Conferences.Find(conferenceID);
                db.Entry(@event).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Conferences = new SelectList(db.Conferences.ToList(), "ConferenceID", "Location", @event.Conference.ConferenceID);
            return View(@event);
        }

        // GET: Events/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Event @event = db.Events.Find(id);
            db.Events.Remove(@event);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
