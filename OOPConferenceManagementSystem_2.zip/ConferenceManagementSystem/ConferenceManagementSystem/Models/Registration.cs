﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ConferenceManagementSystem.Models
{
    public class Registration
    {
        public Registration()
        {
            RegistrationDate = DateTime.Now;
        }

        public int RegistrationID { get; set; }
        [Required(ErrorMessage = "Please enter date of registration")]
        [DataType(DataType.Date, ErrorMessage = "Please enter valid date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime RegistrationDate { get; private set; }

        public virtual Event Event { get; set; }
        public virtual Attendee Attendee { get; set; }
    }
}