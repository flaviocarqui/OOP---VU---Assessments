﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ConferenceManagementSystem.Models
{
    public class Conference
    {
        [Required(ErrorMessage = "Please select Conference")]
        public int ConferenceID { get; set; }
        [Required(ErrorMessage = "Please enter conference location")]
        [Display(Name = "Conference Location")]
        public string Location { get; set; }
        [Required(ErrorMessage = "Please enter year")]
        [Range(1900, 2050, ErrorMessage = "Year should be between 1900 and 2050")]
        public int Year { get; set; }

        public virtual ICollection<Organizer> Organizers { get; set; }
        public virtual ICollection<Event> Events { get; set; }
    }
}