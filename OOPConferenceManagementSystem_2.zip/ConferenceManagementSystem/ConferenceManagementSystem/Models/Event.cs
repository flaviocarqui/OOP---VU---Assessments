﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ConferenceManagementSystem.Models
{
    public class Event
    {
        public int EventID { get; set; }
        [Required(ErrorMessage = "Please enter event name")]
        [Display(Name = "Evnet Name")]
        public string EventName { get; set; }
        [Required(ErrorMessage = "Please enter topic")]
        public string Topic { get; set; }
        [Required(ErrorMessage = "Please enter date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }

        public virtual Conference Conference { get; set; }
        public virtual ICollection<Registration> Registrations { get; set; }
    }
}